<?php
	session_start();
	session_destroy();
	
?>
<link rel="stylesheet" type="text/css" href="style.css">
<p>you are logged out!
</p>
<a href="loginform.php">login again!</a>